﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO; // need this namespace to work with files and directories

namespace ExistingDir
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
