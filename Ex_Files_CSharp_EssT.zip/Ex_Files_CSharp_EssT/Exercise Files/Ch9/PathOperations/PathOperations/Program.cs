﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO; // need this for file and directory information

namespace PathOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
