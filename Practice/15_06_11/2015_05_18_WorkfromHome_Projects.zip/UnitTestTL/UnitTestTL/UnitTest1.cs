﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lib;

namespace UnitTestTL
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
