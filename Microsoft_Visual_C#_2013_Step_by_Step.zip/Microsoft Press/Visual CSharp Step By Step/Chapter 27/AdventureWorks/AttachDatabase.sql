CREATE DATABASE AdventureWorks
ON (NAME='AdventureWorksLT2012_Data', FILENAME='C:\Users\<YourName>\Documents\Microsoft Press\Visual CSharp Step By Step\Chapter 27\AdventureWorks\AdventureWorksLT2012_Data.mdf')
LOG ON (NAME='AdventureWorksLT2012_LOG', FILENAME='C:\Users\<YourName>\Documents\Microsoft Press\Visual CSharp Step By Step\Chapter 27\AdventureWorks\AdventureWorksLT2012_log.ldf')
FOR ATTACH