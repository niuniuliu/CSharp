This project is a class library that defines the Tree<TItem> type. 
It is referenced by the QueryBinaryTree solution.